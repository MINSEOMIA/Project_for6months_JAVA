package imgBoard;

import java.util.ArrayList;

public class Service {
	private Dao dao;
	public Service() {
		dao = new Dao();
	}
	
	public void addImgBoard(ImgBoard ib) {
		dao.insert(ib);
	}
	
	public ImgBoard getImgBoard(int num) {
		return dao.select(num);
	}
	
	public ArrayList<ImgBoard> getAll(){
		return dao.selectAll();
	}
}
