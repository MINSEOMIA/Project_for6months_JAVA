package reps;

public class Rep {
	private int num; // ���� ��� ��ȣ
	private int parent_num; // ���� ��ȣ
	private String writer;
	private String content;

	public Rep() {
	}

	public Rep(int num, int parent_num, String writer, String content) {
		this.num = num;
		this.parent_num = parent_num;
		this.writer = writer;
		this.content = content;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public int getParent_num() {
		return parent_num;
	}

	public void setParent_num(int parent_num) {
		this.parent_num = parent_num;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	@Override
	public String toString() {
		return "Rep [num=" + num + ", parent_num=" + parent_num + ", writer=" + writer + ", content=" + content + "]";
	}

}
