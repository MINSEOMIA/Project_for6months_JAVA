package reps;

import java.util.ArrayList;

public class Service {
	private Dao dao;
	public Service() {
		dao = new Dao();
	}
	
	public void addRep(Rep r) {
		dao.insert(r);
	}
	
	public ArrayList<Rep> getByParentNum(int parentNum){
		return dao.selectByParentNum(parentNum);
	}
}
