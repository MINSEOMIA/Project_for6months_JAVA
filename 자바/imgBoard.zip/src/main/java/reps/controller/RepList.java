package reps.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import reps.Rep;
import reps.Service;

/**
 * Servlet implementation class RepList
 */
@WebServlet("/rep/list")
public class RepList extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RepList() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int parentNum = Integer.parseInt(request.getParameter("num"));
		Service service = new Service();
		ArrayList<Rep> list = service.getByParentNum(parentNum);
		JSONArray jarr = new JSONArray();//[]. json �迭 �ϳ� ����
		for(Rep r:list) {
			JSONObject json = new JSONObject();//{}. �� json ��ü ����
			json.put("num", r.getNum());
			json.put("writer", r.getWriter());
			json.put("content", r.getContent());
			jarr.add(json);  //[{num:1, writer:aaa, content:asdf}, {num:2, writer:aaa, content:asdf}]
		}	
		String j = jarr.toJSONString();//json�� ���ڿ��� ��ȯ. 
		System.out.println(j);
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		response.getWriter().append(j);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
