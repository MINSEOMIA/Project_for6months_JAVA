package member;

public class Service {

	public Member getMember(String id) {
		// TODO Auto-generated method stub
		return null;
	}

}
