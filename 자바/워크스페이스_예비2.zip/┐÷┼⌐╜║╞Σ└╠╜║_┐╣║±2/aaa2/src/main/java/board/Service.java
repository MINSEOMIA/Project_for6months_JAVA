package board;

import java.util.ArrayList;

public class Service {
	private Dao dao;
	
	public Service() {
		dao = new Dao();
	}
	
	//���ۼ�
	public void addBoard(Board b) {
		dao.insert(b);
	}
	
	//�۸��
	public ArrayList<Board> getAll(){
		return dao.selectAll();
	}
	//�� ��ȣ�� �˻�
	public Board getBoard(int num) {
		return dao.select(num);
	}
	//����
	public void editBoard(Board b) {
		dao.update(b);
	}
	//����
	public void delBoard(int num) {
		dao.delete(num);
	}
}
