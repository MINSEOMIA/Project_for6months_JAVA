package member;

public class Service {
	private Dao dao;
	
	public Service() {
		dao = new Dao();
	}
	
	public void join(Member m) {
		dao.insert(m);
	}
	
	public Member getMember(String id) {
		return dao.select(id);
	}
	
	public void editInfo(Member m) {
		dao.update(m);
	}
	
	public void delMember(String id) {
		dao.delete(id);
	}
}
