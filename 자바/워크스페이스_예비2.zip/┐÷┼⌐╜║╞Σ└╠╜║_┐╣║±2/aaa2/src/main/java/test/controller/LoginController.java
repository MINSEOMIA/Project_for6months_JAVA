package test.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import test.Member;
import test.Service;

/**
 * Servlet implementation class LoginController
 */
@WebServlet("/test/LoginController")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher dis = request.getRequestDispatcher("/test/loginForm.jsp");
		dis.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		Service service = new Service();
		String path = "/test/loginForm.jsp";
		//����ȹ��
		HttpSession session = request.getSession();
		int num = Integer.parseInt(request.getParameter("num"));
		String id = request.getParameter("id");
		String pwd = request.getParameter("pwd");

		Member m = service.getMember(num);
		if (m != null) {
			if (m.getId().equals(id) && m.getPwd().equals(pwd)) {
				path = "/test/menu.jsp";
				session.setAttribute("id", id);
			}else {
				request.setAttribute("msg", "id�� ���ų� pwd����ġ");
			}
		}else {
			request.setAttribute("msg", "���� ����� ��ȣ");
		}
		RequestDispatcher dis = request.getRequestDispatcher(path);
		dis.forward(request, response);
	}

}
