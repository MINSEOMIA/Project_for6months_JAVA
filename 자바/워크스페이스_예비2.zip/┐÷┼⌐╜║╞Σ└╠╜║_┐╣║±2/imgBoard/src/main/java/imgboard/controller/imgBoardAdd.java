package imgboard.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import imgboard.ImgBoard;
import imgboard.Service;
import upload.DefaultFileRenamePolicy;
import upload.MultipartRequest;

/**
 * Servlet implementation class imgBoardAdd
 */
@WebServlet("/imgBoardAdd")
public class imgBoardAdd extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public imgBoardAdd() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher dis = request.getRequestDispatcher("/imgboard/addForm.jsp");
	    dis.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String path ="C:\\Users\\Playdata\\Desktop\\workspace\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp1\\";
		com.oreilly.servlet.MultipartRequest req = new MultipartRequest(request,path,100*1024*1024,"utf-8",new DefaultFileRenamePolicy());
		File f = req.getFile("file");
		String fileName = f.getName();
		
		String writer = req.getParameter("writer");
		String title = req.getParameter("title");
		String content = req.getParameter("content");
		
		Service service = new Service();
		service.addImgBoard(new ImgBoard(0, writer, null, title, content, fileName));
		response.sendRedirect(request.getContextpath+"/imgboard/list");
		
		
	}

}
