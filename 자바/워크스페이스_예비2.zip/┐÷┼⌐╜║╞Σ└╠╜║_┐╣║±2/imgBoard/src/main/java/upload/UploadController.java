package upload;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class UploadController
 */
@WebServlet("/UploadController")
public class UploadController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UploadController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String path = "C:\\Users\\Playdata\\Desktop\\ITSTUDY\\�ڹ�\\��ũ�����̽�\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp0\\webapps\\imgs";
		response.setContentType("text/html; charset=UTF-8");
		//���ε尡 ������ multipartrequest ��û ó�� ��ü
		//parameter1: request
		//pm2: ���ε� ���� ������ ���
		//pm3: ���� �ִ� ũ��
		//pm4: ���ڵ�
		//pm5: �ߺ�����ó��-�⺻
		build path "/cos.jar")
		MultipartRequest req = new MultipartRequest(request,path,100*1024*1024,"utf-8",new DefaultFileRenamePolicy());
		//���ε�
		req.getFile("file1");
		String title= req.getParameter("title");
		File dir= new File(path);
		String[] files = dir.list()://���丮 ���� ��� �迭�� ��ȯ
		request.setAttribute("files", files);
		RequestDispatcher dis= request.getRequestDispatcher("fileUpload/list.jsp");
		response.getWriter().append("���ε� ����.title:"+title);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
