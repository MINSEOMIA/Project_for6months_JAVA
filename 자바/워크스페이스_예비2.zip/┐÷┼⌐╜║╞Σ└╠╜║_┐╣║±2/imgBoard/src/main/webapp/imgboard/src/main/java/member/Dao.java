package member;

public class Dao {
	public void insert(Member m) {}
	public Member select(String id) {return null;}
	public void update(Member m) {}
	public void delete(String id) {}
}
