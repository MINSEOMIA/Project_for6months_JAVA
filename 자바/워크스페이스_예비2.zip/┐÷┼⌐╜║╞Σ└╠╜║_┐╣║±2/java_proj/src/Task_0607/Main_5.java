package Task_0607;

import java.util.Scanner;

import p0603.addr.ans.Menu;

public class Main_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		Menu_4 m = new Menu_4();
		m.run(sc);
	}

}
