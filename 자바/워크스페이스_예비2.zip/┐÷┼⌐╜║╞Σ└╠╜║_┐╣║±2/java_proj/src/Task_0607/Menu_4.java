package Task_0607;

import java.util.Scanner;

import p0603.addr.Service;

public class Menu_4 {

	Service_3 service;
	Menu_4() {
		service = new Service_3();
	}
	
	void run(Scanner sc) {
		boolean flag = true;
		int m;
		while(flag) {
			System.out.println("1.��ǰ��� 2.�˻� 3.���� 4.���� 5.�԰� 6.��� 7.��ü��� 8.����");
			m=sc.nextInt();
			switch(m) {
			case 1:
				service.addProduct_1(sc);
				break;
			case 2:
				service.
				break;
			case 3:
				break;
			case 4:
				break;
			case 5:
				service.printAll();
				break;
			case 6:
				flag = false;
				break;
			}
		}
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
