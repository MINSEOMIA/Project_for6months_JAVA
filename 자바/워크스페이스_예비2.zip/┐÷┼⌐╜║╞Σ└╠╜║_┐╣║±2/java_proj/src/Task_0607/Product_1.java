package Task_0607;
//vo. ��ǰ��ȣ(�ڵ��Ҵ�),��ǰ��,����,����
public class Product_1 {
	int num;
	String name;
	int count;
	int price;
	
	public Product_1(int num, String name, int count, int price) {
		this.num = num;
		this.name = name;
		this.count = count;
		this.price = price;
	}
	

	@Override
	public String toString() {
		return "Product_1 [num=" + num + ", name=" + name + ", count=" + count + ", price=" + price + "]";
	}





	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
