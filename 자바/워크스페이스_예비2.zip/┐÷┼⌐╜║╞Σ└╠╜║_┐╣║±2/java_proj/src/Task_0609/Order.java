package hw2.store;

import hw2.warehouse.Product;

//�ֹ� vo
//����(�ֹ���ȣ(�ڵ��Ҵ�), �ֹ���ǰ��ü(Product), �ֹ�����, �����ݾ�, ��������, �������
public class Order {
	private int num;
	private Product p;
	private int amount;
	private int payment;
	private boolean isPay;//false
	private boolean isOut;//false
	private static int cnt;

	public Order() {
	}

	public Order(Product p, int amount) {
		this.num = ++cnt;
		this.p = p;
		this.amount = amount;
		this.payment = this.amount * this.p.getPrice();
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public Product getP() {
		return p;
	}

	public void setP(Product p) {
		this.p = p;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public int getPayment() {
		return payment;
	}

	public void setPayment(int payment) {
		this.payment = payment;
	}

	public boolean isPay() {
		return isPay;
	}

	public void setPay(boolean isPay) {
		this.isPay = isPay;
	}

	public boolean isOut() {
		return isOut;
	}

	public void setOut(boolean isOut) {
		this.isOut = isOut;
	}

	@Override
	public String toString() {
		return "Order [num=" + num + ", p=" + p + ", amount=" + amount + ", payment=" + payment + ", isPay=" + isPay
				+ ", isOut=" + isOut + "]";
	}

}
