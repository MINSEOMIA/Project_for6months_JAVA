package hw2.store;

import java.util.Scanner;

import hw2.warehouse.Product;

public class OrderService {
	private OrderDao dao;

	public OrderService() {
		dao = new OrderDao();
	}

	public void addOrder(Scanner sc, Product p) {
		System.out.println("�ֹ�����:");
		int amount = sc.nextInt();
		dao.insert(new Order(p, amount));
	}

	public void printAll() {
		Order[] data = dao.selectAll();
		for (Order o : data) {
			System.out.println(o);
		}
	}
}
