package hello;

public class LoopTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i;
		for(i=0;i<6;i++){
		 System.out.print("#");
		 if(i%3 == 2){
		   System.out.println(); 
		   }
		}
        int j;
		for(i=0;i<2;i++){
		   for(j=0;j<3;j++){
			System.out.print("#");
		   }
		   System.out.println(); 
		 }
	
		//������ 2-9�� ���
	   for(i = 2;i <10;i++){ //�ܼ�
		System.out.println(i +"��");
	   }for(j = 1; j <10;j++){ //���ϴ� ��
		   System.out.println(i + "*"+ j +"="+ i*j); 
	 }
   }


	   }
	
		
	}

}
