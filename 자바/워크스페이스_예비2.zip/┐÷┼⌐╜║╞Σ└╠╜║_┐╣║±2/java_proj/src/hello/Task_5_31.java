package hello;

import java.util.Scanner;

public class Task_5_31 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//제어문 과제
/* 1. 아래 삼각형 출력(크기 입력받음)
		*
		**
		***
		****               */
		
Scanner sc = new Scanner(System.in);
System.out.println("삼각형 크기 입력하시오");
int scale1 = sc.nextInt();
//for (int i = 1; i = scale1; i++) { // *에러
for (int i = 1; i <= scale1; i++) { // i= 행의 횟수
	for (int j = 0; j < i; j++) { // j = '*'의 갯수
		System.out.print("*");
	}
	System.out.println();
}
	/* Q 
	 ->	행의 갯수를 입력받은 크기만큼 만들고싶은데
      i <= scale 은 실행되면서 i =(=)scale을 같다고 놓으면 에러가 나서
	  어떻게 해야할지 모르겠다.. 아래로도 동일문제가 이어짐 -> 깨달음;; <=로 쓰는게 원래 맞다;*/	
//'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''//		
/* 2. 아래 삼각형 출력(크기 입력받음)
   *
  **
 ***
****                    */


System.out.println("크기 입력하시오");
int scale2 = sc.nextInt();
for (int i = 0; i < scale2 ; i++) {
	for(int j = scale2 - 1 ; j > 0; j-- ) {
		if(i < j) {
			System.out.print(" ");
		}else // i 가 j보다 클때만
			System.out.print("*");
	}
	System.out.println();
}
	
//''''''''''''''''''''''''''''''''''''''''''''''''''''''
/*3. 아래 삼각형 출력(크기(밑변) 입력받음) 홀수 별갯수=(2*줄갯수)-1
  *
 ***
*****                               */

System.out.println("base 입력하시오");
float base = sc.nextFloat();
 for(int i = 1; i <= base ; i++ ) {
	 for(int j = i; j < base ; j++ ) {
		 System.out.print(' ');
	 }
	 for(int j =1; j <= (2* i) -1 ; j++) {
		 System.out.print("*");
	 }
	 System.out.println();
 }
//''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
/*4. 아래 마름모 출력(크기(중간줄) 입력받음)
  *
 ***
*****
 ***
  *      Q:중간줄...입력...? 중간줄을 기준으로 위 아래 두 섹션으로 나눠서 풀어야하나? */

System.out.println("mid 입력하시오");
float mid = sc.nextFloat();
static void prob4(int size) {
	int m = size / 2+ 1; //중심의 위치
    int k = m-1; //스페으스에서 발표로 변환되는 위치
    int val = 0; //각 줄마다 출력할 캐릭터 개수 제어
    for(int i=0; i< size; i++) { //전체 줄수
		char ch = ' ';
		for(int j =0; j < m+ val; j++) { //각 줄마다 출력하는 캐릭터 수
			 if (j == k) {
				 ch = '*';
			 }
			System.out.print(ch);
		}
			if(i < m -1) {
				k-- ;
				val++;
			} else }
			  val -- ;
			  k++;
			}
			System.out.println();
  	 }
	}


//''''''''''''''''''''''''''''''''''''''''''''''''''''''''
// 6. 구구단 가로로 출력(2-9단)
for(int i =2; i <10 ; i++) {
	for (int j =1; j< 10; j++) {
		System.out.print(i + "*"+ j + "=" + i*j+" " );
	}
 	System.out.println();
 }


// print 랑 println의 차이!
//''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
/* 7. 1-100사이 소수 출력(소수: 약수가 1과 자신밖에 없는 수) #2부터 n/2까지 나눴을때 나누어지는 숫자가 존재하지 않으면 소수
막혀서 찾아봄... */
for(int i = 2; i <= 100 ; i ++ ) { //소수는 2부터 존재함 i = 나눠지는 수 =' i / j '
	for (int j = 2; j <= i; j++) { // j = 나누는 수
     if(i%j ==0){  
    	
  /* --여기에서 부터 막혔다 ㅜㅜ 힌트를 찾아봄..다시 풀어봐야한다. flag 처리안한거 count 채우는거 이슈임
소수는  약수가 1과 자기 자신 뿐인 자연수. 그 외의 다른 약수가 존재하면 소수가 아님.
입력받은 수를 i로 나누었을 때 0일 경우가 존재하면 소수가 아님. (단 1과 자기 자신은 제외)
1과 자기 자신을 제외할 때까지 반복하려면 시작값을 2 끝값을 (자기 자신-1)까지 설정.
소수가 아닐 경우 break;로 for문 종료. 소수일 경우 소수 변수에 입력받은 수를 대입.
출력 시 문제가 되지 않도록 boolean flag 변수 선언을 해 주었다. (flag는 아래에 설명)
-boolean flag = 
다른 프로그램이나 다른 로직에 신호를 남기거나 보내기 위해 사용하는 값(변수)프로그램에서는 주로 boolean 변수로 사용한다.깃발을 신호용으로 ( ex - 경주, 함선 간 신호, 전투 시의 신호) 쓰곤 하던 전통에서 따온 용어.
프로그램 로직이 끝나는 시점과 결과값이 나오는 시점이 다를 때 사용하면 편리.
프로그램 로직을 처리하는 도중 결과값이 나오지만 결과값에 상관없이 끝까지 실행되어야 하는 경우 결과값을 플래그로 저장해놓는다.
출처: https://kimdevel.tistory.com/39 [고졸에서 개발자까지:티스토리]  */
     }
	}
}

static void prob5(int num) {
	System.out.println(num + "의 약수");
	for(int i =1; i <= num; i++) {
		if(num % 1 == 0) {
			System.out.print(i + "\t");
	}
}
	System.out.println();
}
	static void prob6() {
		int cnt = 0;
		System.out.println("1~100사이의 소수 출력");
		for(int i =2; i <= 100; i++) {
			cnt = 0;
			if(int j = 2; j <i; j++) {
				if (i %j == 0) {
					cnt++;
				}
			}
			if (cnt == 0) {
				System.out.print(i + "\t");
			}
		}
		System.out.println();
	}
/* ++ 더 풀어본 비슷한 문제들
# 12의 약수 문제 /약수= 어떤 수 이하의 자연수 중에서 나머지가 0 */
for (int i = 1; i <= 12; i++) {
			if (12 % i == 0) {
				System.out.println(i);
			}
		}

/*100 이하의 자연수 중 8의 배수 문제 */

for(int i = 1 ; i <=100 ; i++) {
	if (i % 8 == 0) {
		System.out.print(i + ", ");
	}
}
	}

}

