package hello;

public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         char x; //변수선언 -> 메모리 할당
         x = 'a'; //값 할당, 문자하나
         
         String y = "asdf"; //문자열
         
         //System.in 표준입력(키보드)
         //System.out 표준입력(콘솔)
         System.out.println("hello java");  	
         System.out.print("111"); 
         System.out.print("222");
         
         System.out.println("\nx" + x);
         System.out.println("y" + y);
         //String b = "asdf"+123;
         
	}

}

class A{}

class B{}
