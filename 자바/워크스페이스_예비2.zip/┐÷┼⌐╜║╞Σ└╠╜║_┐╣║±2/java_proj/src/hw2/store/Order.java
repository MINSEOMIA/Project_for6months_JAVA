package hw2.store;

public class Order {
	private int num;
	private Product p;
	private int amount;
	private int payment;
	private boolean isPay;
	private boolean isOut;
	private static int cnt;
	
	public Order() {
	}

	public Order(Product p, int amount) {
		this.num = ++cnt;
		this.p = p;
		this.amount = amount;
		this.payment = this.amount * this.p.getPrice();
	}
	
	public int getNum() {
		return num;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
