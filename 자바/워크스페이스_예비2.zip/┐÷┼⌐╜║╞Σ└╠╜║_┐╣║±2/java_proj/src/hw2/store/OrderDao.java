package hw2.store;

public class OrderDao {

	private Order[] orders;
	private int cnt;
	
	public OrderDao() {
		orders = new Order[30];
	}
	
	//�ֹ��߰�
	public void insert(Order o) {
		if (cnt > 29) {
			System.out.println("�迭��");
		}else {
			orders[cnt++] = o;
		}
	}
	
	//��ȣ�� �˻��Ͽ� Order ��ü ��ȯ
	public void selectByNum(int num) {
		for(Order o:orders) {
			if(num == o.getNum()) {
				return o;
			}
		}
		return null;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
