package p0531_5_31;

public class SwitchTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int x = 3;
		switch(x) {
		case 1:
			System.out.println("x is 1");
			break;
		case 2:
			System.out.println("x is 2");
			break;
		default:
			System.out.println("x is under 5");
			break;

		}
		
		
	String ����="ȭ";
	switch(����) {
	case "��":
		System.out.println("������");
		break;
	case "ȭ":
		System.out.println("ȭ����");
		break;
	case "��":
		System.out.println("������");
		break;
	
	}
	
	
	
	
	
	
	}

}
