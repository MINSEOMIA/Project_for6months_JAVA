package p0602;

public class ArrTest3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        char[] a = {'a', 'b', 'c'};
        byte[] b = {1,2,3};
        double[] c = {2.34, 5.67};
        
    	for(char i: a) {
			System.out.println(i);
		}
		for(byte i: b) {
			System.out.println(i);
	}
		for(double i: c) {
			System.out.println(i);
	}
}

}
