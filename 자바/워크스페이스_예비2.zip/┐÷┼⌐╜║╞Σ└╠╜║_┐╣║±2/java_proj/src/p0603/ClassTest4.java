package p0603;

class Person {
	int age = 12;
	String name = "asdf";
	
	Person(){
		System.out.println("������ ȣ���");
		age = 100;
		name = "�ҸӴ�";
	}

	void setPerson(int a, String n) {
		age = a;
		name = n;
	}

	void printPerson() {
		System.out.println("age:" + age);
		System.out.println("name:" + name);
	}
}
public class ClassTest4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Person p = new Person();
		p.printPerson();
		p.setPerson(23, "aaa");
		p.printPerson();
	}
	
	}

}
