package p0603;


	class Score {
		int kor, eng, math, total;
		float avg;
		Score(int k, int e, int m){
		kor = k;
		eng =e;
		math =m;
		total = kor+eng+math;
		avg = (float)total/3;
	}
		
		
//	void printScore() {
	//System.out.print(kor+ "\t");
	//System.out.print(eng+ "\t");
	//System.out.print(math+ "\t");
	//System.out.print(total+ "\t");
	//System.out.print(avg+ "\t");
	//System.out.println();
//}
	
	}
	
	class Student3{
		int num;
		String name;
		String dept;
		Score score; //���԰���
		
		Student3(int nu, String na, String dept, Score s) {
			num = nu;
			name = na;
			dept = d;
			score = s;
		}

		@Override
		public String toString() {
			return "Student3 [num=" + num + ", name=" + name + ", dept=" + dept + ", score=" + score + "]";
		}
	}
	
public class StudentTest3 {
	//student ������ �Է� �޼���
	static Student3 input(Scanner sc) {
		System.out.print("num: ");
		int num = sc.nextInt();
	    
		System.out.print("name: ");
		String name = sc.nextInt();
		System.out.print("dept: ");
		String dept = sc.nextInt();
		System.out.print("kor: ");
		int kor = sc.nextInt();
		System.out.print("eng: ");
		int eng = sc.nextInt();
		System.out.print("math: ");
		int math = sc.nextInt();
		
		return new Student3(num, name, dept, new Score(kor, eng, math));
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner sc = new Scanner(System.in);
		//Student3 Ÿ�� �迭 ����
		Student3[] st= new Student3[3];
		//input() �Լ��� �л� ���� �Է¹ް� �� �����͸� Studenmt3 ��ü�����Ͽ� ����
		for(int i=0; i<st.length; i++) {
			st[i] = input(sc);
		}
		//�迭 ��� ���
		for(Student3 s3: st) {
			System.out.println(s3);
		}
	}

}
