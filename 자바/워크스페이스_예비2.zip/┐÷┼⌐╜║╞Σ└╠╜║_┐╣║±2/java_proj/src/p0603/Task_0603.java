package p0603;
//vo. �� ����� name, tel, address
public class Task_0603 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
