package p0603.addr;

import java.util.Scanner;
//���� Ŭ����, ����ڿ� ������ ��� ����
public class Service {
	Dao dao;
	
	
	Service(){
		dao = new Dao();
	}
	
	
	
	//�߰� ���
	void addPerson(Scanner sc) {
		System.out.print("name: ");
		String name = sc.next();
		System.out.print("tel: ");
		String tel = sc.next();
		System.out.print("address: ");
		String address = sc.next();
		
		dao.insert(new Person(name, tel, address));
		
	}
	void printAll() {
		for(int i=0; i<dao.cnt; i++) {
			System.out.println(dao.datas[i]);
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
