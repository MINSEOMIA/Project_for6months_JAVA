package p0603.addr.ans;
//vo. �� ����� name, tel, address
public class Person {

	String name;
	String tel;
	String address;
	
	public Person(String name, String tel, String address) {
		this.name = name;
		this.tel = tel;
		this.address = address;
	}

	@Override
	public String toString() {
		return "Person [name=" + name + ", tel=" + tel + ", address=" + address + "]";
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
