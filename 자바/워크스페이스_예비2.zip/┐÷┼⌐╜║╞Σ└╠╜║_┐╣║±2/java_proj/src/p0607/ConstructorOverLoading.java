package p0607;
class Test5{
	String name;
	String tel;
	
	//������ ���� �ε�
	Test5(){
		name = "�ƹ���";
		tel = "0000";
	}

	Test5(String name){
		this.name = name;
		tel= "1111";
	}
	Test5(String name, String tel){
		this.name = name;
		this.tel= "1111";
}
public class ConstructorOverLoading {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
