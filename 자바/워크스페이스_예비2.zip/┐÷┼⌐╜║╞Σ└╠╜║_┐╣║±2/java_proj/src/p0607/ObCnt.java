package p0607;
class Test2{
	static int cnt;
	
	
	Test2(){
		cnt++;
		Test t2 = new Test();
		System.out.println(cnt + " ��° ��ü ������");
	}
}



public class ObCnt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Test2[]arr = new Test2[5];
		for (int i =0; i< 5; i++) {
			arr[i] = new Test2();
		}
	}

}
