package p0607;

class Test {
	int a;
	static int b;
	
	void method() {
		a++;
		b++;
	}
	void printAB() {
		System.out.println("a:" + a);
		System.out.println("b" + b);
	}
}

public class StaticTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Test t1 = new Test();
		t1.method();
		t1.printAB();
		System.out.println(t1.a);
		System.out.println(Test.b);
		
		Test t2 = new Test();
		t2.method();
		t2.printAB();
		
		Test t3 = new Test();
		t3.method();
		t3.printAB();
	}

}
