package p0609;

public class Picachu extends PocketMon {
	public Picachu() {
		name = "��ī��";
		hp = 30;
		exp = 0;
		lv = 1;
	}

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		super.eat();// �޽��� ���
		hp += 5;
	}

	@Override
	public void sleep() {
		// TODO Auto-generated method stub
		super.sleep();
		hp += 10;
	}

	@Override
	public boolean play() {
		// TODO Auto-generated method stub
		super.play();
		hp -= 8;
		if (hp <= 0) {
			printInfo();
			return false;
		}
		exp += 5;
		levelCheck();
		return true;
	}

	@Override
	public boolean exc() {
		// TODO Auto-generated method stub
		super.exc();
		hp -= 13;
		if (hp <= 0) {
			printInfo();
			return false;
		}
		exp += 10;
		levelCheck();
		return true;
	}

	@Override
	public void levelCheck() {
		// TODO Auto-generated method stub
		super.levelCheck();
		if (exp >= 20) {
			System.out.println("���� 1 ����");
			lv++;
			exp -= 20;
		}
	}
}
