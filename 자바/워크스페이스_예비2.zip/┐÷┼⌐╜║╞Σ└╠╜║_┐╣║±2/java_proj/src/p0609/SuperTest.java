package p0609;
class A {
	int a;

	// public A() {}
	public A(int a) {
		this.a = a;
	}
}

class B extends A {
	int b;

	public B(int a, int b) {
		super(a);// �θ� Ŭ���� ������ ȣ��
		this.b = b;
	}
}

public class SuperTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		B b = new B(1, 2);
		System.out.println("b.a:" + b.a);
		System.out.println("b.b:" + b.b);
	}
	}


