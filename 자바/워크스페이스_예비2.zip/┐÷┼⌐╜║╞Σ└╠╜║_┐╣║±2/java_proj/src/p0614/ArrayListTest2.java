package p0614;
import java.util.ArrayList;

class Test2 {
	int a;
	String b;

	public Test2(int a, String b) {
		this.a = a;
		this.b = b;
	}

	@Override
	public String toString() {
		return "Test2 [a=" + a + ", b=" + b + "]";
	}

}
public class ArrayListTest2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// ArrayList ����. <>���ʸ�. Ÿ��������. String�� �㵵�� ����
				ArrayList<String> list1 = new ArrayList<String>();
				list1.add("aaa");
				list1.add("bbb");
				list1.add("ccc");
				for (String s : list1) {
					System.out.println(s);
				}
				for (int i = 0; i < list1.size(); i++) {
					System.out.println(list1.get(i));
				}

				// ArrayList ����. <>���ʸ��� Test2�� ����. ������ Ÿ���� Test2����
				ArrayList<Test2> list2 = new ArrayList<Test2>();
				list2.add(new Test2(1, "zzz"));
				list2.add(new Test2(2, "yyy"));
				list2.add(new Test2(3, "xxx"));

				for (Test2 s : list2) {
					System.out.println(s);
				}
				for (int i = 0; i < list2.size(); i++) {
					System.out.println(list2.get(i).a + " / " + list2.get(i).b);
				}
	}

}
