package p0614;
import java.util.ArrayList;
public class ArrayListTest3 {
	

	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<String> list = new ArrayList<String>();
		list.add("aaa");
		list.add("bbb");
		list.add("ccc");
		list.add(0, "eee");
		list.set(1, "abc");
		System.out.println("bbb ���ԵǾ��ֳ�?" + list.contains("bbb"));
		System.out.println("bbb ��ġ:" + list.indexOf("bbb"));
		System.out.println("��ü���:" + list);
		list.remove(1);
		System.out.println("��ü���:" + list);
		list.remove("eee");
		System.out.println("��ü���:" + list);
		list.clear();
		if (list.isEmpty()) {
			System.out.println("����Ʈ ��");
		}

	}
	}


