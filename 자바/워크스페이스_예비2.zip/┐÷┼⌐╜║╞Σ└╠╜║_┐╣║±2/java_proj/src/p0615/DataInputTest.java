package p0615;
import java.io.FileNotFoundException;
import java.io.FileInputStream;
import java.io.DataInputStream;

public class DataInputTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
