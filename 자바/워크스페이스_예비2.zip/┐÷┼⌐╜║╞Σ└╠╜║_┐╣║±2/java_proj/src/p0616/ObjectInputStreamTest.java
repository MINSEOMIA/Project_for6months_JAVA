package p0616;

public class ObjectInputStreamTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
