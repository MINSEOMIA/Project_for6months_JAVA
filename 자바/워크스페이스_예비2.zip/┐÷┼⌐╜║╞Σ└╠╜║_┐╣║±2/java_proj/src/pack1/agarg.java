package pack1;

public class agarg {
	public static void main(String[] argv) {

	}
}