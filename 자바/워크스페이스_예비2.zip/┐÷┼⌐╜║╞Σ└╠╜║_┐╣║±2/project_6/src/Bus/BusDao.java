package Bus;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import reserve.MysqlConnect;
import reserve.Res;

public class BusDao {
	private MysqlConnect dbconn;

	public BusDao() {
		dbconn = MysqlConnect.getInstance();
	}

	// �����Ҹ��� �뼱��ȣ�� �޾Ƽ� ��ġ�ϴ� ������ ���� ��쿡 false��ȯ
	public boolean select(Res r) {
		Connection conn = dbconn.getConn();
		ResultSet rs; //
		String sql = "select * from bus_station where ars = ? and ars = ? and rtNm = ? ";

		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, r.getBusin());
			pstmt.setString(2, r.getBusout());
			pstmt.setString(3, r.getLoadnum());

			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} 
		return false;
	}

	// ��ġ�� ��쿡�� �����Ҹ� ����ID ������ ��ȯ����.
	public String SelectArsId(String s) {
		String b = null;
		ResultSet rs = null; 
		
		Connection conn = dbconn.getConn();
		String sql = "select arsid from bus_station where ars = ? ";

		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, s);

			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				b = rs.getString(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} 
		return b;
	}

 public String SelectArsId2(String b) {
	
 }
 }