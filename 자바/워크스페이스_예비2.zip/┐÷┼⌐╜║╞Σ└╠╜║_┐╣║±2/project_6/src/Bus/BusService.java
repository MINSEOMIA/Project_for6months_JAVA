package Bus;

import java.util.ArrayList;

import hw.warehouse.Product;
import reserve.Res;

public class BusService {
	private BusDao dao;
	public static String arsid = "";

	public BusService() {
		dao = new BusDao();
	}
	
	// ����ID ��ȯ
	public void knowArsId(Res r) {
		String s = r.getBusin();
		dao.SelectArsId(s);
	}
	// ��ü���
	public void SelectArsid2 {
		//ArrayList<Product> list = dao.selectAll();
		for (String b) {
			System.out.println(b);
		}
	}
}