package Busdetail;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import reserve.MysqlConnect;
import reserve.Res;

public class BdDao {
   private MysqlConnect dbconn;

   public BdDao() {
      dbconn = MysqlConnect.getInstance();
   }

   // �Է��� �ؾ��Ҷ�(���� ��������) ------------ ���� ���忡�� �����Ǵ°���?
   public void insert(BdVo bd) {
      Connection conn = dbconn.getConn();
      String sql = "insert into bus_detail(arsld, busline, buscompany, bnum, bustype, arrivetime, congestion)"
            + "values(?, ?, ?, ?, ?, ?, ?)";

      try {
         PreparedStatement pstmt = conn.prepareStatement(sql);
         pstmt.setString(1, bd.getArsld());
         pstmt.setString(2, bd.getBusline());
         pstmt.setString(3, bd.getBuscompany());
         pstmt.setString(4, bd.getBnum());
         pstmt.setInt(5, bd.getBustype());
         pstmt.setDate(6, bd.getArrivetime());
         pstmt.setInt(7, bd.getCongestion());

         pstmt.executeUpdate();
      } catch (SQLException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      } finally {
         try {
            conn.close();
         } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
         }
      }
   }

   // ���� �������� �ҷ��� �� ------------ ���� ���忡�� �����Ǵ°���?
   public void select(String busline) {
      ResultSet rs = null;
      Connection conn = dbconn.getConn();
      String sql = "select * from bus_detail where busline=?";

      try {
         PreparedStatement pstmt = conn.prepareStatement(sql);
         pstmt.setString(1, busline);
         rs = pstmt.executeQuery();

      } catch (SQLException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      } finally {
         try {
            conn.close();
         } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
         }
      }
   } // ���� ����/���� �ʿ�?
}
