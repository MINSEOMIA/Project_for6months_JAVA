apackage BusDetail;

public class BdMain {

}
