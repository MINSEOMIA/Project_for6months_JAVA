package BusDetail;

import reserve.Res;

public class BdService {

public void knowArsId(BusDao b ) {
	
}


//����ID ��ȯ
	public void knowArsId(Res r) {
		String s = r.getBusin();
		dao.SelectArsId(s);
	}
}
