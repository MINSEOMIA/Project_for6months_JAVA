package BusDetail;


import java.sql.Date;

//VO
public class BdVo {
   private String busline; // �뼱��
   private String buscompany; // ����ȸ��
   private int resnum; // �����ȣ --------- �ڵ��Ҵ� �Ǵ� ��ȣ �̷��� ������?
   private String bnum; // ������ȣ
   private int bustype;// �������������� ���� ����
   private Date arrivetime;// �������������� ���� ���� �޽���(��� �� ����)
   private int congestion;// ���� ȥ�⵵
 
   private String arsid;
   public BdVo() {
   }

   public BdVo(String busline, String buscompany, int resnum, String bnum, int bustype, Date arrivetime,
         int congestion) {
      this.busline = busline;
      this.buscompany = buscompany;
      //this.resnum = resnum;
      this.bnum = bnum;
      this.bustype = bustype;
      this.arrivetime = arrivetime;
      this.congestion = congestion;
   }

   public String getBusline() {
      return busline;
   }

   public void setBusline(String busline) {
      this.busline = busline;
   }

   public String getBuscompany() {
      return buscompany;
   }

   public void setBuscompany(String buscompany) {
      this.buscompany = buscompany;
   }

   public int getResnum() {
      return resnum;
   }

   public void setResnum(int resnum) {
      this.resnum = resnum;
   }

   public String getBnum() {
      return bnum;
   }

   public void setBnum(String bnum) {
      this.bnum = bnum;
   }

   public int getBustype() {
      return bustype;
   }

   public void setBustype(int bustype) {
      this.bustype = bustype;
   }

   public Date getArrivetime() {
      return arrivetime;
   }

   public void setArrivetime(Date arrivetime) {
      this.arrivetime = arrivetime;
   }

   public int getCongestion() {
      return congestion;
   }

   public void setCongestion(int congestion) {
      this.congestion = congestion;
   }
   
   public void SelectArsId(String b) {
	   this.arsid= arsid;
   }

   @Override
   public String toString() {
      return "BdVo [busline=" + busline + ", buscompany=" + buscompany + ", resnum=" + resnum + ", bnum=" + bnum
            + ", bustype=" + bustype + ", arrivetime=" + arrivetime + ", congestion=" + congestion + ", arsid=" + arsid+"]";
   }


}