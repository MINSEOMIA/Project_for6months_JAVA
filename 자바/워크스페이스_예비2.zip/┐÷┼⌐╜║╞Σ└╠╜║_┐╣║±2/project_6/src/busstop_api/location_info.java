package busstop_api;

public class location_info {

}
