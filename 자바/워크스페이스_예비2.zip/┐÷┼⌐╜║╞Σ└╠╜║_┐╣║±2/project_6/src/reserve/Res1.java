package reserve;

import java.sql.Date;

//VO �����ϱ� ���� �ʿ��� ���� ��� Ŭ����
public class Res {
   private int num;// �����ȣ(�ڵ��Ҵ�)
   private String busin;// ���� �����Ҹ�
   private String busout;// ���� �����Ҹ�
   private String pnum;// �ڵ�����ȣ
   private String loadnum;// �뼱��ȣ(�뼱)
   private String busnum; // ������ȣ(����)
   private boolean isres; // ���࿩��(T/F)
   private boolean isin; // ž�¿���(T/F)
   private Date restime;// �����û�ð�
   private Date intime; // ���������ð�
   private Date outtime; // ���������ð�
   private String remark; // ���
   private static int cnt;

   // ������
   public Res() {
   }

   // ���� �� �ڵ����� �Ҵ��� ������
   public Res(String busin, String busout, String pnum, String loadnum) {
      this.num = ++cnt;
      this.busin = busin;
      this.busout = busout;
      this.pnum = pnum;
      this.loadnum = loadnum;
   }

   // ���� �� �ڵ����� �Ҵ��� ������2
   public Res(int num, String busin, String busout, String pnum, String loadnum, String busnum, boolean isres,
         boolean isin, Date restime, Date intime, Date outtime, String remark) {
      this.num = num;
      this.busin = busin;
      this.busout = busout;
      this.pnum = pnum;
      this.loadnum = loadnum;
      this.busnum = busnum;
      this.isres = isres;
      this.isin = isin;
      this.restime = restime;
      this.intime = intime;
      this.outtime = outtime;
      this.remark = remark;
   }

   public int getNum() {
      return num;
   }

   public void setNum(int num) {
      this.num = num;
   }

   public String getBusin() {
      return busin;
   }

   public void setBusin(String busin) {
      this.busin = busin;
   }

   public String getBusout() {
      return busout;
   }

   public void setBusout(String busout) {
      this.busout = busout;
   }

   public String getPnum() {
      return pnum;
   }

   public void setPnum(String pnum) {
      this.pnum = pnum;
   }

   public String getLoadnum() {
      return loadnum;
   }

   public void setLoadnum(String loadnum) {
      this.loadnum = loadnum;
   }

   public String getBusnum() {
      return busnum;
   }

   public void setBusnum(String busnum) {
      this.busnum = busnum;
   }

   public boolean isIsres() {
      return isres;
   }

   public void setIsres(boolean isres) {
      this.isres = isres;
   }

   public boolean isIsin() {
      return isin;
   }

   public void setIsin(boolean isin) {
      this.isin = isin;
   }

   public Date getRestime() {
      return restime;
   }

   public void setRestime(Date restime) {
      this.restime = restime;
   }

   public Date getIntime() {
      return intime;
   }

   public void setIntime(Date intime) {
      this.intime = intime;
   }

   public Date getOuttime() {
      return outtime;
   }

   public void setOuttime(Date outtime) {
      this.outtime = outtime;
   }

   public String getRemark() {
      return remark;
   }

   public void setRemark(String remark) {
      this.remark = remark;
   }

   public static int getCnt() {
      return cnt;
   }

   public static void setCnt(int cnt) {
      Res.cnt = cnt;
   }

   @Override
   public String toString() {
      return "Res [num=" + num + ", busin=" + busin + ", busout=" + busout + ", pnum=" + pnum + ", loadnum=" + loadnum
            + ", busnum=" + busnum + ", isres=" + isres + ", isin=" + isin + ", restime=" + restime + ", intime="
            + intime + ", outtime=" + outtime + ", remark=" + remark + "]";
   }

}