package reserve;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.mysql.cj.x.protobuf.MysqlxCrud.Order;

public class ResDao {
   private MysqlConnect dbconn;

   public ResDao() {
      dbconn = MysqlConnect.getInstance();
   }

   // ���� �Է�
   public void insert(Res r) {
      Connection conn = dbconn.getConn();
      String sql = "insert into bus_res(busin, busout, pnum, loadnum) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

      try {
         PreparedStatement pstmt = conn.prepareStatement(sql);
         pstmt.setInt(1, r.getNum());
         pstmt.setString(2, r.getBusin());
         pstmt.setString(3, r.getBusout());
         pstmt.setString(4, r.getPnum());
         pstmt.setString(5, r.getLoadnum());
         pstmt.setString(6, r.getBusnum());
         pstmt.setBoolean(7, r.isIsres());
         pstmt.setBoolean(8, r.isIsin());
         pstmt.setDate(9, r.getRestime());
         pstmt.setDate(10, r.getIntime());
         pstmt.setDate(11, r.getOuttime());
         pstmt.setString(12, r.getRemark());

         pstmt.executeUpdate();
      } catch (SQLException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      } finally {
         try {
            conn.close();
         } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
         }
      }
   }

   // ���� ó��(T/F)
   // -------------------------------------------------------------------------
   public boolean reserve(int num) {
      // 1. db����
      Connection conn = dbconn.getConn();
      // 2. sql
      String sql = "update bus_res set isres=true where num=? and isres=false";

      try {
         PreparedStatement pstmt = conn.prepareStatement(sql);
         pstmt.setInt(1, num);

         int congestion = pstmt.executeUpdate(); // congestion (ȥ��: 5 ����: 4 ����: 3)
         int bustype = pstmt.executeUpdate(); //����:1 �Ϲ�:0
         if (((congestion == 4) || (congestion == 3)) && (bustype == 1)) {
            return true; // ���� ����
         }
      } catch (SQLException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      } finally {
         try {
            conn.close();
         } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
         }
      }
      return false; // ���� ����
   }


   // ����ó�� ���� �˻�
   public ArrayList<Res> selectByIsRes(String pnum) {
      ArrayList<Res> list = new ArrayList<Res>();
      ResultSet rs = null;

      // 1. db����
      Connection conn = dbconn.getConn();

      // 2. sql
      String sql = "select * from bus_res where pnum=? order by num";

      try {
         PreparedStatement pstmt = conn.prepareStatement(sql);
         pstmt.setString(1, pnum);
         rs = pstmt.executeQuery();

         while (rs.next()) {
            list.add(new Res(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),
                  rs.getString(6), rs.getBoolean(7), rs.getBoolean(8), rs.getDate(9), rs.getDate(10), rs.getDate(11),
                  rs.getString(12)));
         }

      } catch (SQLException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      } finally {
         try {
            conn.close();
         } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
         }
      }
      return list;
   }

   // �����ȣ�� ���� ���� ���
   public boolean delete(int num) {
      Connection conn = dbconn.getConn();
      String sql = "delete from bus_res where num=? and isres=True";

      try {
         PreparedStatement pstmt = conn.prepareStatement(sql);
         pstmt.setInt(1, num);
         int cnt = pstmt.executeUpdate();
         if(cnt>0) {
            return true; //���� ��� �Ϸ�
         }
      } catch (SQLException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      } finally {
         try {
            conn.close();
         } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
         }
      }
      return false; // ���� ��� �ȵ�
   }

   /*
    * ž��
    * ó��(T/F)----------------------------------------------------------------------
    * ---------- public boolean board(int num) { // 1. db���� Connection conn =
    * dbconn.getConn(); // 2. sql String sql =
    * "reserve from bus_res where isres = False";
    * 
    * try { PreparedStatement pstmt = conn.prepareStatement(sql); pstmt.setInt(1,
    * num); int congestion = pstmt.executeUpdate(); if ((congestion == 0) ||
    * (congestion == 1)) { return true; // ž�� ���� } } catch (SQLException e) { //
    * TODO Auto-generated catch block e.printStackTrace(); } finally { try {
    * conn.close(); } catch (SQLException e) { // TODO Auto-generated catch block
    * e.printStackTrace(); } } return false; // ž�� ���� }
    */
}