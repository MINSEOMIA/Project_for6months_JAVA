package com.example.demo.guestbook;

import java.util.ArrayList;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/guestbook")  //현재 컨트롤러의 기본 url등록
public class BoardController {
	@Autowired
	private BoardService service;
	}
	
	@GetMapping("/add") //하나 추가
	public void addForm() {}
	
	@PostMapping("/add")
	public String add(Board b) {
		service.addBoard(b);
		return "redirect:/board/";  //sendredirect()
	}
	@RequestMapping("/")
	public String list(Model model) {
		ArrayList<Board> list = service.getAll();
		model.addAttribute("list",list);
		return "board/list";
	
}
