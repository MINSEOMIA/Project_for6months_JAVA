package com.example.demo.member;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller  //클래스 stereotype을 Controller 지정
@RequestMapping("/member")	//이 컨트롤러의 기본 url
public class MemController {
	@Autowired		//자동 의존성 주입
	private MemService service;
	
	@GetMapping("/login")  //url 등록
	public String loginForm() {
		return "member/loginForm";
	}
	
	@PostMapping("/login")
	public String login(String id, String pwd, HttpSession session) {
		Member m = service.getMember(id);
		if(m!=null && pwd.equals(m.getPwd())) {
			session.setAttribute("id", id);
			session.setAttribute("type", m.isMem_type());
		}
		return "redirect:/"; //response.sendRedirect("http://localhost:8081/");
	}
	
	@GetMapping("/join")
	public String joinForm() {
		return "member/joinForm";
	}
	
	@PostMapping("/join")
	public String join(Member m) {
		service.join(m);
		return "redirect:/";
	}
	
	@GetMapping("/detail")
	public String detail(HttpSession session, Model mm) {
		String id = (String) session.getAttribute("id");
		Member m = service.getMember(id);
		mm.addAttribute("m", m);
		return "member/detail";
	}
	
	@GetMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/";
	}
	
	@PostMapping("/edit")
	public String edit(Member m) {
		service.editMember(m);
		return "redirect:/";
	}
	
	@RequestMapping("/out")  //get, post 모두 요청 받을 수 있게하기 위해
	public String out(HttpSession session) {
		String id = (String) session.getAttribute("id");
		service.delMember(id);
		return "redirect:/member/logout";
	}
	
	@GetMapping("/list")
	public String list(Model m) {
		ArrayList<Member> list = service.getAll();
		m.addAttribute("list", list);
		return "member/list";
	}
	
	@GetMapping("/idcheck")
	public void idcheck(String id, Model model) {
		Member m = service.getMember(id);
		boolean flag = false;
		if(m==null) {
			flag = true;
			model.addAttribute("id", id);
		}
		model.addAttribute("flag", flag);
	}
	
	@ResponseBody	//뷰 페이지 경로가 아니라 뷰를 생성하여 반환
	@GetMapping("/test")
	public String test() {
		return "hello response body!!";
	}
	
	@ResponseBody
	@GetMapping("/idcheck2")
	public Map idcheck2(String id) {//맵을 반환하면 json형태의 텍스트 반환
		Map map = new HashMap();
		Member m = service.getMember(id);
		boolean flag = false;
		String id2 = "";
		if(m==null) {
			flag = true;
			id2 = id;
		}
		map.put("id", id2);
		map.put("flag", flag);
		return map;
	}
}



