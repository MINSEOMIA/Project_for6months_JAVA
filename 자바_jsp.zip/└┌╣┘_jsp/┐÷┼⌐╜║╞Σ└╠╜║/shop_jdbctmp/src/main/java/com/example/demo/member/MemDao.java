package com.example.demo.member;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class MemDao {
	@Autowired
	private JdbcTemplate temp;

	public class MemberMapper implements RowMapper<Member> {

		@Override
		public Member mapRow(ResultSet rs, int rowNum) throws SQLException {
			// TODO Auto-generated method stub
			return new Member(rs.getString(1), rs.getString(2), rs.getBoolean(3), rs.getString(4), rs.getString(5));
		}

	}

	public void insert(Member m) {
		String sql = "insert into member values(?,?,?,?,?)";
		temp.update(sql, new Object[] {m.getId(), 
		m.getPwd(), m.isMem_type(), m.getTel(), m.getAddr()});
	}

	public Member select(String id) { //하나검색
		String sql = "select * from member where id=?";
		Member m = null;
		try {
			
		m = temp.queryForObject(sql, new MemberMapper(), id); //ForObject 메서드는 검색결과 없으면 예외발생, 예외처리 해줘야함
	}catch(EmptyResultDataAccessException e) {
		m = null;
	}
		return m;
	}

	public ArrayList<Member> selectAll(){//전부검색
		String sql = "select * from member";
		return (ArrayList<Member>) temp.query(sql, new MemberMapper());
	}
	
	public void update(Member m) { //수정
		String sql = "update member set pwd=?, tel=?, addr=? where id=?";
		temp.update(sql, new Object[] {	m.getPwd(),  m.getTel(), 
				m.getAddr(), m.getId()});
	}

	public void delete(String id) {
		String sql = "delete from member where id=?";
		temp.update(sql, id);
	}
}

	
	
	
}
