package com.example.demo.member;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MemService {
	@Autowired
	private MemberDao dao;

	// 가입
	public void join(Member m) {
		dao.insert(m);
	}

	// 로그인, 내정보확인
	public Member getMember(String id) {
		return dao.select(id);
	}

	// 내정보수정(pwd, addr, tel 수정)
	public void editMember(Member m) {
		dao.update(m);
	}

	// 탈퇴
	public void delMember(String id) {
		dao.delete(id);
	}
	
	//전체검색
	public ArrayList<Member> getAll(){
		return dao.selectAll();
	}
}
