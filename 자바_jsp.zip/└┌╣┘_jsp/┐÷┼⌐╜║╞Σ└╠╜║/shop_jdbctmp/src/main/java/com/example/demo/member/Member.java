package com.example.demo.member;

public class Member {

}
