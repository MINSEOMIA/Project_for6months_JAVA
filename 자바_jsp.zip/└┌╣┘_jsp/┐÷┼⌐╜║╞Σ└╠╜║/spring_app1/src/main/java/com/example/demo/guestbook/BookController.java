package com.example.demo.guestbook;

import java.util.ArrayList;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/guestbook") //현재 컨트롤러의 기본 url 등록
public class BookController {
	@Autowired
	private BookService service;
	
	@GetMapping("/")
	public String list(Map map) {
		ArrayList<GuestBook> list = service.getAll();
		map.put("list", list);
		return "guestbook/list";
	}

	@GetMapping("/add") //하나 추가
	public String
	
	@PostMapping("/add")
	public String add(GuestBook gb) {
		service.addBook(gb);
		return "redirect:/guesbook/"; //sendredirect()
	}
}


/* package com.example.demo.guestbook;

import java.util.ArrayList;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/guestbook")  //현재 컨트롤러의 기본 url등록
public class BookController {
	@Autowired
	private BookService service;
	
	@GetMapping("/") //전체검색
	public String list(Map map) {//파람으로 Map, ModelMap을 작성하면 이 객체에 담은 정보는 자동으로 뷰페이지로 전달
		ArrayList<GuestBook> list = service.getAll();
		map.put("list", list);
		return "guestbook/list";
	}
	
	@GetMapping("/add") //하나 추가
	public void addForm() {}
	
	@PostMapping("/add")
	public String add(GuestBook gb) {
		service.addBook(gb);
		return "redirect:/guestbook/";  //sendredirect()
	}
	
}
*/