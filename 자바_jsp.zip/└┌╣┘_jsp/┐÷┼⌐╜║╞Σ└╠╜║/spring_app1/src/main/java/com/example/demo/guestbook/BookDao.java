package com.example.demo.guestbook;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class BookDao {
	
	@Autowired
	private JdbcTemplate temp; //db sql문을 쉽게 처리할 수 있게 자동화 처리
	
	//검색결과 담을 resultMaP 정의
	public class BookMapper implements RowMapper<GuestBook> { //테이블 한줄을 VO에 맵핑할수 있도록 정의

    @Override
    public GuestBook
			// TODO Auto-generated constructor stub
		GuestBook gb = new GuestBook();
		gb.setNum(rs.getInt(1));
		
		
		return gb;
		}

	public void insert(GuestBook gb) {
		String sql = "insert into guestbook(writer, w_date,title,content) values(?, now(), ?, ?)";
		temp.update(sql, new Object[] {gb.getWriter(), gb.getTitle(), gb.getContent()});
	}
	public GuestBook select(int num) {
		return null;
	}
	public ArrayList<GuestBook> selectAll() {
		return null;
	}
	public void update(GuestBook gb) {
		
	}
	public void delete(int num) {
		
	}
}
/* package com.example.demo.guestbook;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class BookDao {
	
	@Autowired
	private JdbcTemplate temp; //db sql문을 쉽게 처리할 수 있게 자동화 처리.
	
	//검색 결과 담을 resultMap정의. 
	public class BookMapper implements RowMapper<GuestBook>{//테이블 한줄을 vo에 맵핑할 수 있도록 정의

		@Override
		public GuestBook mapRow(ResultSet rs, int rowNum) throws SQLException {
			// TODO Auto-generated method stub
			GuestBook gb = new GuestBook();
			gb.setNum(rs.getInt(1));
			gb.setWriter(rs.getString(2));
			gb.setW_date(rs.getDate(3));
			gb.setTitle(rs.getString(4));
			gb.setContent(rs.getString(5));
			return gb;
		}
	}
	//jdbcTemplate.update():insert,update,delete실행 
	//jdbcTemplate.queryForObject():primary key 기준 검색. 결과는 한줄이거 0줄
	//jdbcTemplate.query(): 목록검색. 검색결과 여러줄. 
	public void insert(GuestBook gb) {
		String sql = "insert into guestbook(writer, w_date, title, content) values(?, now(), ?, ?)";
		//param1:sql문
		//param2:?매칭값 목록
		temp.update(sql, new Object[] {gb.getWriter(), gb.getTitle(), gb.getContent()});
	}
	
	public GuestBook select(int num) {
		String sql = "select * from guestbook where num=?";
		//param1:sql문
		//param2:resultMap
		//param3:?매칭값
		GuestBook gb = temp.queryForObject(sql, new BookMapper(), num);
		return gb;
	}
	
	public ArrayList<GuestBook> selectAll(){
		String sql = "select * from guestbook";
		//param1:sql문
		//param2:resultMap
		ArrayList<GuestBook> list = (ArrayList<GuestBook>) temp.query(sql, new BookMapper());
		return list;
	}
	
	public void update(GuestBook gb) {
		String sql = "update guestbook set title=?, content=? where num=?";
		//param1:sql문
		//param2:?매칭값 목록
		temp.update(sql, new Object[] {gb.getTitle(), gb.getContent(), gb.getNum()});
	}
	
	public void delete(int num) {
		String sql = "delete from guestbook where num=?";
		//param1:sql문
		//param2:?매칭값
		temp.update(sql, num);
	}
}


 
 */


