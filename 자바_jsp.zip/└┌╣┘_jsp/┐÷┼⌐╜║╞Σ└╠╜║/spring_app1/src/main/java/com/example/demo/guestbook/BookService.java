package com.example.demo.guestbook;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BookService {
	@Autowired
	private BookDao dao;

	public void addBook(GuestBook gb) {
		dao.insert(gb);
	}

	public GuestBook getBook(int num) {
		return dao.select(num);
	}

	public ArrayList<GuestBook> getAll() {
		return dao.selectAll();
	}

	public void editBook(GuestBook gb) {
		dao.update(gb);
	}

	public void delBook(int num) {
		dao.delete(num);
	}
}
