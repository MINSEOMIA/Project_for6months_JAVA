package com.example.demo.test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;


//컨트롤러, 요청 url별로 서비스 구현
//처리한 url 등록, 요청시 실행할 내용 메서드로 구현

@Controller //ct+sh+o 자동임포트
public class TestController {
		@Autowired
		private TestService service;

		@RequestMapping("/home") //요청 url 등록, get, post 둘다 가능
		public String home() { //매핑 매서드의 반환값이 String이면 뷰 페이지 경로
			return "home"; //경로: webinf/ views/ home.jsp
		}
		@GetMapping("/home2")
		public void home2(String id, String pwd) { //반환타입 void면 url과 동일한 경로의 뷰페이지 이동
			System.out.println(id);
			System.out.println(pwd);
			service.del();
			//return "home2";
		
		}
		@PostMapping("/home2")
		public String home22(@ModelAttribute("mm") Member m) { //m은 뷰페이지로 자동 전달 
			System.out.println(m);
			service.get();
			return "result";
			
		}
		
		
}
