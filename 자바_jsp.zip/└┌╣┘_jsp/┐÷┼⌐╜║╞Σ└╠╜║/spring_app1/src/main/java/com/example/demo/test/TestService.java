package com.example.demo.test;

import org.springframework.beans.factory.annotation.Autowired;

public class TestService {

		@Autowired //자동의존성 주입 타입같은 객체를 자동으로 넣어줌
	private Dao dao;
	}

}