package com.encore.jpa.board;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;

import com.encore.jpa.member.Member;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Entity
@Getter
@Setter
//@NoArgsConstructor
//@AllArgsConstructor
@ToString

	

public class Board {

	@Id //primary key
	@GeneratedValue(strategy=GenerationType.IDENTITY) //AUTO-INCREMENT
	private int num;
	
	@ManyToOne //=다대일 , OneToOne(일대일), OneToMany일대다, ManyToMany다대다
	@JoinColumn(nullable=false) //member 테이블 id칼럼에 join
	private Member writer; //member 테이블 id칼럼에 join
	
	private String writer;
	
	private Date w_date;
	private String title;
	private String content;
	
	@PrePersist //inserst 전 미리 실행
	public void beforeCreate() {
		w_date = new Date(); //현재 날짜 생성
	}

}
