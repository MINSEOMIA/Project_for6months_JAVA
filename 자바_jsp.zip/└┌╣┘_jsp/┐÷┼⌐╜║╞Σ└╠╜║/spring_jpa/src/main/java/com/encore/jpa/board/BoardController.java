package com.encore.jpa.board;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/board")
public class BoardController {
	@Autowired
	private BoardService service;
	
	@GetMapping("/add")
	public void addForm() {}
	
	@PostMapping("/add")
	public String add(Board b) {
		service.addBoard(b);
		return "redirect:/board/";
	}
	
	@RequestMapping("/")
	public String list(Model model) {
		ArrayList<Board> list = service.getAll();
		model.addAttribute("list", list);
		return "board/list";
	}

	@ResponseBody
	@GetMapping("/getByNum")
	public Map getByNum(int num) {
		Map map = new HashMap();
		Board b = service.getByNum(num);
		map.put("num", b.getNum());
		map.put("writer", b.getWriter());
		map.put("w_date", b.getW_date());
		map.put("title", b.getTitle());
		map.put("content", b.getContent());
		return map;
	}
	
	@PostMapping("/getbywriter")
	public String getbywriter(String val, Model model) {
		ArrayList<Board> list = service.getByWriter(val);
		model.addAttribute("list", list);
		return "board/list";
	}
	
	@PostMapping("/getbytitle")
	public String getbytitle(String val, Model model) {
		ArrayList<Board> list = service.getByTitle(val);
		model.addAttribute("list", list);
		return "board/list";
	}
	
	@GetMapping("/detail")
	public void detail(int num, Model model) {
		Board b = service.getByNum(num);
		model.addAttribute("b", b);
	}
	
	@PostMapping("/detail")
	public String edit(Board b) {
		b.setw_date(new.Date());
		service.editBoard(b);
		return "redirect:/board/";
	}
	
	@GetMapping("/del")
	public String detail(int num) {
		service.delBoard(num);
		return "redirect:/board/";
	}
}






