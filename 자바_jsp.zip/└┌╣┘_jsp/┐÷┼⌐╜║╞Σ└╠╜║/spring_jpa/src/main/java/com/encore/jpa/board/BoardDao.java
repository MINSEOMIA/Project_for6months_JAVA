package com.encore.jpa.board;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BoardDao extends JpaRepository<Board, Integer> {
	ArrayList<Board> findByTitleLike(String title); //제목으로 검색
	ArrayList<Board> findByTitleWriter(Member Writer); //작성자로 검색
	

}
