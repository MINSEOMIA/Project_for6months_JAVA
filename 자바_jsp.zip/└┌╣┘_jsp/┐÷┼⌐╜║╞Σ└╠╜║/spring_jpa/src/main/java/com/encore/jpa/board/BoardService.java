package com.encore.jpa.board;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BoardService {
	@Autowired
	private BoardDao dao;
	
	public Board addBoard(Board b) {
		return dao.save(b);
	}
	
	public Board getByNum(int num) {
		return dao.findById(num).orElse(null);
	}
	
	public ArrayList<Board> getAll(){
		return (ArrayList<Board>) dao.findAll();
	}
	
	public ArrayList<Board> getByTitle(String title){
		return dao.selectByTitleLike(title);
	}
	
	public ArrayList<Board> getByWriter(Member writer){
		return dao.selectByWriter(writer);
	}
	
	public void editBoard(Board b) {
		dao.update(b);
	}
	
	public void delBoard(int num) {
		dao.delete(num);
	}
}