package com.encore.jpa.member;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface MemDao extends JpaRepository<Member, String> {

}

//save(): insert(), update(모든컬럼수정)
//findById(id):primary key 기준 검색
//listfindAll(): 전체검색
//void deletebyid() : primary key 기준 삭제
//검색에  where절 추가
//list findby 컬럼명
//list findby 컬럼명like(like절 추가)