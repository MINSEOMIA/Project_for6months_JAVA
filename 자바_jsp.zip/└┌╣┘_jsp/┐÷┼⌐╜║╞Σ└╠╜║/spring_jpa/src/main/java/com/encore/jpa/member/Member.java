package com.encore.jpa.member;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Entity
@Getter
@Setter
//@NoArgsConstructor
//@AllArgsConstructor
@ToString


public class Member {
	
	@id //primary 값 설정 
	private String id;
	
	@Column(nullable=false) // 컬럼설정, 컬럼명, 제약조건 등  nullable=false :not null
	private String pwd;
	
	private boolean mem_type;
	private String tel;
	private String addr;

}
