package com.encore.upload;

public class SpringRestApiApplication {

}
