package com.encore.upload.guestbook;

public class GBController {

}
