package com.encore.jpa.member;

public class Member {

}
