package com.encore.jpa.mydownload;

public class DownController {

}
