package com.encore.jpa.myupload;

public class ImgVo {

}
