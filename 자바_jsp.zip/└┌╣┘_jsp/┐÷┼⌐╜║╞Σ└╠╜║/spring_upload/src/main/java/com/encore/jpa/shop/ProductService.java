package com.encore.jpa.shop;

public class ProductService {

}
