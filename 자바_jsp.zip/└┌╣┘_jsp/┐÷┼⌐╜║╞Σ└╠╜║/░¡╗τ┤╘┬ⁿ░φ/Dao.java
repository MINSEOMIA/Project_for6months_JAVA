package product;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import conn.MysqlConnect;

public class Dao {
	private MysqlConnect dbconn;

	public Dao() {
		dbconn = MysqlConnect.getInstance();
	}

	// ��ǰ���
	public void insert(Product p) {
		Connection conn = dbconn.getConn();
		String sql = "insert into product(num, name,info,price,amount,seller,img1) values(?,?,?,?,?,?,?)";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, p.getNum());
			pstmt.setString(2, p.getName());
			pstmt.setString(3, p.getInfo());
			pstmt.setInt(4, p.getPrice());
			pstmt.setInt(5, p.getAmount());
			pstmt.setString(6, p.getSeller());
			pstmt.setString(7, "");
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

	public int makeNum() {
		ResultSet rs = null;
		Connection conn = dbconn.getConn();
		String sql = "select MAX(num)+1 from product";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();// �˻��� ����� ResultSet���� ��ȯ
			if (rs.next()) {
				return rs.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return -1;
	}

	public void updateImgs(Product p) {
		Connection conn = dbconn.getConn();
		String sql = "update product set img1=?, img2=?, img3=? where num=?";

		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, p.getImg1());
			pstmt.setString(2, p.getImg2());
			pstmt.setString(3, p.getImg3());
			pstmt.setInt(4, p.getNum());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	// �� ��� ��ǰ ���.
	public ArrayList<Product> selectBySeller(String seller) {
		return null;
	}

	// ����(��ǰ �̸�, ����, ����, ����)
	public void update(Product p) {
	}

	// ����
	public void delete(int num) {
	}

	// ��ǰ ��ȣ�� �˻�
	public Product selectByNum(int num) {
		return null;
	}

	// ��ǰ������ �˻�
	public ArrayList<Product> selectByName(String name) {// like ���ڿ� ���� �˻�
		return null;
	}

	// ���ݴ�� �˻�
	public ArrayList<Product> selectByPrice(int price1, int price2) {// between and
		return null;
	}

	// ��ü�˻�
	public ArrayList<Product> selectAll() {
		return null;
	}
}
