package product.controller;

import java.io.File;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import product.Product;
import product.Service;

/**
 * Servlet implementation class ProdAdd
 */
@WebServlet("/prod/add")
public class ProdAdd extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ProdAdd() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	// ��ǰ ��� ������. /product/addForm.jsp�� �̵�
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setAttribute("path", "/product/addForm.jsp");
		RequestDispatcher dis = request.getRequestDispatcher("/index.jsp");
		dis.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	// ��� �Ϸ�. �� ��ǰ ��� ������� �̵�
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		Service service = new Service();
		int num = service.makeNum();// ��ǰ��ȣ ����

		String imgPath = "C:\\Users\\Playdata\\Desktop\\workspace\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp1\\webapps\\shop\\";

		String dirName = imgPath + num;

		File dir = new File(dirName);
		if (!dir.exists()) {
			dir.mkdir();
		}
		// cos.jar�� ������ Ŭ����. ���Ͼ��ε� ������ Ŭ����
		MultipartRequest req = new MultipartRequest(request, dirName, 100 * 1024 * 1024, "utf-8",
				new DefaultFileRenamePolicy());

		String seller = req.getParameter("seller");
		String name = req.getParameter("name");
		String info = req.getParameter("info");
		int price = Integer.parseInt(request.getParameter("price"));
		int amount = Integer.parseInt(request.getParameter("amount"));
		File img1 = req.getFile("img1");
		File img2 = req.getFile("img2");
		File img3 = req.getFile("img3");
		String img1Name = "/shop/"+num+"/"+img1.getName(); 
		String img2Name = "/shop/"+num+"/"+img2.getName(); 
		String img3Name = "/shop/"+num+"/"+img3.getName(); 
		
		service.addProduct(new Product(num, name, info, price, amount, seller, img1Name, img2Name, img3Name));

		request.setAttribute("path", "/prod/list");
		RequestDispatcher dis = request.getRequestDispatcher("/index.jsp");
		dis.forward(request, response);
	}

}
